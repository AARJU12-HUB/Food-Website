document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
    const name = document.getElementById('name').value;
    document.getElementById('form-message').innerText = `Thank you for your message, ${name}! We will get back to you shortly.`;
});
